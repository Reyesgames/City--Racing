# Crazy Racing
An html5 car-racing game.

- **Author:** Yuehao Wang
- **Game Engine:** [lufylegend.js](http://lufylegend.com/lufylegend)
- Materials come from the Internet and I am here to say thanks to those contributors.
- Support main-stream web browsers, iOS and Android.

## Play Online
URL: http://yuehaowang.github.io/games/crazy_racing/index.html

## Screenshot
**Game Page:**

![Screenshot](http://yuehaowang.github.io/images/demo/crazy_racing1.png)
